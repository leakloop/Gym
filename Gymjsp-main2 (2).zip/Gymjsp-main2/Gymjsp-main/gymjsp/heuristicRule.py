import queue
import random
import itertools
from collections import deque

#启发式算法#

def fifo(env):

    """First-In, First-Out."""
    m = env.num_machines  # m=机器数
    machine_input = [queue.Queue() for _ in range(m)]  # 创建一个队列，用于存储等待处理的作业
    # his =[] # set函数创建一个无序不重复元素的集合，用于跟踪已经被分配到机器的作业
    res=[]
    reward, count = 0, 0
    t = env.global_time  # 仿真时间
    while env.global_time-t < env.schedule_cycle:
        #  循环直到仿真时间到达调度周期的末尾
        state = env.get_machine_doable_action() # 获取可以执行的操作
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    machine_input[machine_id].put(ops_id)  # 对于某个机器所对应的操作集，如果ops_id不在集合中就加入进去，同时加到队列里
        for i in his:
            if i not in res:
                res.append(i)
        his=res
        available_machines_id = env.get_available_machines_id() # 获得所有空闲的机器的序号
        if not available_machines_id:
            env.process_one_second() # 获取不到可用的机器序号，意味着机器都在工作，那么就让他们保持工作。
        else: # 有机器可以使用
            # for q in machine_input:
            #  if machine_id in available_machines_id:
            #
            #         if not q.empty():
            #             ops_id = q.get()
            #             job_id, step_id = env.job_manager.sur_index_dict[ops_id]
            #             operation = env.job_manager[job_id][step_id]
            #             operation.machine_id = machine_id
            #             machine = env.machine_manager[machine_id]
            #             action = operation
            #             machine.transit(env.global_time, action)
            her=[]
            for machine_id, machine_q in enumerate(machine_input): # enumerate可以同时读取索引和元素值
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilink(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty(): # 如果队列里有元素
                        # pp=[5,6]
                        # if machine_id in pp:
                        #     for i in list(machine_q.queue):
                        #         her.append(machine_q.get())
                        #         random.shuffle(her)
                        #     for i in her:
                        #         machine_q.put(i)

                        ops_id = machine_q.get() # 从队列里读取元素赋值给ops_id
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        # sur_index_dict（）：Job中包含的按顺序编号的操作
                        # 从集合中读出job_id和step_id，例如job0 step 0 ，表示作业0的第0步工序
                        operation = env.job_manager[job_id][step_id] # job_id和step_id所对应的矩阵的元素
                        machine_id = operation.machine_id # 矩阵里的机器序号
                        machine = env.machine_manager[machine_id]
                        # action=operation
                        # operation.start_time = env.global_time
                        # next_free_time = env.finish_times(machine, operation, env.global_time)
                        # if next_free_time is None or operation.start_time >= next_free_time:
                        #     machine.transit(env.global_time, action)
                        action = operation
                        machine.transit(env.global_time, action) # 进行一个动作并且返回奖励值

        reward += env.cal_reward() # 累加奖励值
        count += 1 # 次数加一
    return reward / count


def lifo(env):
    """Last in, first out."""
    m = env.num_machines
    machine_input = [queue.LifoQueue() for _ in range(m)]
    res=[]
    reward, count = 0, 0
    t = env.global_time
    his=[]
    while env.global_time-t < env.schedule_cycle:
         
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    machine_input[machine_id].put(ops_id)  # put函数  将元素加入序列的尾端
        for i in his:
            if i not in res:
                res.append(i)
        his = res
        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilink(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                        # if c:
                        #     machine_q.put(ops_id)
                        ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count


def lpt(env):
    """Longest processing time."""
    m = env.num_machines
    machine_input = [queue.PriorityQueue() for _ in range(m)]
    res=[]

    reward, count = 0, 0
    t = env.global_time
    while env.global_time-t < env.schedule_cycle:
         
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    pro = env.get_process_time(ops_id)
                    machine_input[machine_id].put((-pro, ops_id))
        for i in his:
             if i not in res:
                res.append(i)
        his = res

        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilinke(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1][1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty():
                        _, ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count


def spt(env):
    """Shortest processing time."""
    m = env.num_machines
    machine_input = [queue.PriorityQueue() for _ in range(m)]
    res=[]

    reward, count = 0, 0
    t = env.global_time
    while env.global_time-t < env.schedule_cycle:
         
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    pro = env.get_process_time(ops_id)
                    machine_input[machine_id].put((pro, ops_id))
        for i in his:
            if i not in res:
                res.append(i)
        his = res
        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilinke(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1][1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty():
                        _, ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count


def ltpt(env):
    """Longest Total Processing Time."""
    m = env.num_machines
    machine_input = [queue.PriorityQueue() for _ in range(m)]
    res=[]

    reward, count = 0, 0
    t = env.global_time
    while env.global_time-t < env.schedule_cycle:
         
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    pro = env.get_job_process_time(ops_id)
                    machine_input[machine_id].put((-pro, ops_id))
        for i in his:
            if i not in res:
                res.append(i)
        his = res
        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilinke(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1][1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty():
                        _, ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count


def stpt(env):
    """Shortest Total Processing Time."""
    m = env.num_machines
    machine_input = [queue.PriorityQueue() for _ in range(m)]
    res=[]

    done = False
    reward, count = 0, 0
    t = env.global_time
    while env.global_time-t < env.schedule_cycle:
         
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    pro = env.get_job_process_time(ops_id)
                    machine_input[machine_id].put((pro, ops_id))
        for i in his:
            if i not in res:
                res.append(i)
        his = res
        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilinke(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1][1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty():
                        _, ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count


def mor(env):
    """Most Operation Remaining."""
    m = env.num_machines
    machine_input = [queue.PriorityQueue() for _ in range(m)]
    res=[]

    t = env.global_time
    reward, count = 0, 0
    while env.global_time-t < env.schedule_cycle:
         
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    pro = env.get_num_remain_ops(ops_id)
                    machine_input[machine_id].put((-pro, ops_id))
        for i in his:
            if i not in res:
                res.append(i)
        his = res
        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilinke(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1][1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty():
                        _, ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count


def lor(env):
    """Least Operation Remaining"""
    m = env.num_machines
    machine_input = [queue.PriorityQueue() for _ in range(m)]
    res=[]
    t = env.global_time
    reward, count = 0, 0
    while env.global_time-t < env.schedule_cycle:
        state = env.get_machine_doable_action()
        his=[]
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
                    pro = env.get_num_remain_ops(ops_id)
                    machine_input[machine_id].put((pro, ops_id))
        for i in his:
            if i not in res:
                res.append(i)
        his = res
        available_machines_id = env.get_available_machines_id()
        if not available_machines_id:
            env.process_one_second()
        else:
            for machine_id, machine_q in enumerate(machine_input):
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilinke(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1][1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                    # if not machine_q.empty():
                        _, ops_id = machine_q.get()
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]
                        machine_id = operation.machine_id
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)
        reward += env.cal_reward()
        count += 1
    return reward / count

def asap(env,b,myiter,ceil):
    """As Soon As Possible Plus."""
    m = env.num_machines  # m=机器数
    o = []
    res = []
    n=-1
    for i in range(len(env.job_manager.jobs)):
        o.append(env.job_manager.jobs[i])
    machine_input = [queue.Queue() for _ in range(m)]  # 创建一个队列，用于存储等待处理的作业
    his = []  # set函数创建一个无序不重复元素的集合，用于跟踪已经被分配到机器的作业
    reward, count = 0, 0
    t = env.global_time  # 仿真时间
    while env.global_time - t < env.schedule_cycle:
        #  循环直到仿真时间到达调度周期的末尾
        state = env.get_machine_doable_action()  # 获取可以执行的操作
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break
        his=[]

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    # for i in range(len(o)):
                    #     job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                    #     if job_id == o[i].job_id:
                    #         for j in range(len(o[i].ops)):
                    #             if step_id == o[i].ops[j].step_id:
                    #                 processing_time[ops_id] = o[i].ops[j].processing_time  # 使用某一种排序算法，每次循环比较processing time的大小，若小移到队列前面。
                    #         break
                    his.append(ops_id)
        for i in his:
            if i not in res:
                res.append(i)  # 去除重复元素
        for ops_id in res:
            lo=round(ops_id / m)
            job_id, step_id = env.job_manager.sur_index_dict[ops_id]
            operation = env.job_manager[job_id][step_id]
            if operation.processing_time != 0 and getnextop(operation,ceil).processing_time == 0 and operation.prev_op is not None and isin(lo,b):
                for i in range(m):
                    if len(state[i]) > 1:
                        vidd = list(itertools.permutations(res))
                        n = len(vidd)
                        for machine_id in range(m):
                            for xx in state[machine_id]:
                                job_id, step_id = env.job_manager.sur_index_dict[xx]
                                operation = env.job_manager[job_id][step_id]
                                if operation.processing_time != 0 and getnextop(operation,ceil).processing_time == 0 and operation.prev_op is not None:  # 满足条件后，修改res的顺序
                                    for vid, perm in enumerate(itertools.permutations(res)):
                                        if vid == myiter:
                                            res = list(perm)
                                            myiter=myiter+1
                                            break
                                        else:
                                            continue
                                    break

                # if myiter==n:
                #     iterdonne=True







        # 遍历所有数组元素
        # for ops_id in res:
        #     if ops_id/8!=0:
        #         job_id, step_id = env.job_manager.sur_index_dict[ops_id - 1]
        #         prend_time[ops_id] = env.job_manager.jobs[job_id].ops[step_id].endtime
        # for i in range(n):
        #     # 最后i个元素已经排好序，无需再比较
        #     for j in range(n - i - 1):
        #         # 如果当前元素比后面的元素大，则交换它们
        #
        #         if prend_time(env, res[j], m) > prend_time(env, res[j + 1], m):
        #             res[j], res[j + 1] = res[j + 1], res[j]
        #         # elif prend_time(env,res[j],m)==prend_time(env,res[j+1],m):
        #         #     temp.append(res[j])
        #         #     temp.append(res[j+1])
        #         #     temp = random.sample(temp, len(temp))
        #         #     res[j]=temp[0]
        #         #     res[j+1]=temp[1]
        for ops_id in res:
            for machine_id in range(m):
                for xx in state[machine_id]:
                    if ops_id == xx:
                        machine_input[machine_id].put(ops_id)  # 对于某个机器所对应的操作集，如果ops_id不在集合中就加入进去，同时加到队列里
        available_machines_id = env.get_available_machines_id()  # 获得所有空闲的机器的序号
        if not available_machines_id:
            env.process_one_second()  # 获取不到可用的机器序号，意味着机器都在工作，那么就让他们保持工作。
        else:  # 有机器可以使用
            # 两个流同时（都）执行
            # for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
            #     if machine_id in available_machines_id:
            # if multilink(env, machine_input, available_machines_id):  # 存在节点中有多于两条流的后继节点不同等待的情况

            # for q in machine_input:
            #  if machine_id in available_machines_id:
            #
            #         if not q.empty():
            #             ops_id = q.get()
            #             job_id, step_id = env.job_manager.sur_index_dict[ops_id]
            #             operation = env.job_manager[job_id][step_id]
            #             operation.machine_id = machine_id
            #             machine = env.machine_manager[machine_id]
            #             action = operation
            #             machine.transit(env.global_time, action)
            for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, z = multilink(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = z
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                        ops_id = machine_q.get()  # 从队列里读取元素赋值给ops_id
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        # sur_index_dict（）：Job中包含的按顺序编号的操作
                        # 从集合中读出job_id和step_id，例如job0 step 0 ，表示作业0的第0步工序
                        operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                        machine_id = operation.machine_id  # 矩阵里的机器序号
                        machine = env.machine_manager[machine_id]
                        # action=operation
                        # operation.start_time = env.global_time
                        # next_free_time = env.finish_times(machine, operation, env.global_time)
                        # if next_free_time is None or operation.start_time >= next_free_time:
                        #     machine.transit(env.global_time, action)
                        action = operation
                        machine.transit(env.global_time, action)  # 进行一个动作并且返回奖励值
        reward += env.cal_reward()  # 累加奖励值
        count += 1  # 次数加一
    return reward / count,n

def asapplus(env):
    """As Soon As Possible Plus."""
    m = env.num_machines  # m=机器数
    o = []
    res = []
    temp=[]
    processing_time = [0] * 1000
    for i in range(len(env.job_manager.jobs)):
        o.append(env.job_manager.jobs[i])
    machine_input = [queue.Queue() for _ in range(m)]  # 创建一个队列，用于存储等待处理的作业
    his = []  # set函数创建一个无序不重复元素的集合，用于跟踪已经被分配到机器的作业
    reward, count = 0, 0
    t = env.global_time  # 仿真时间
    while env.global_time - t < env.schedule_cycle:
        #  循环直到仿真时间到达调度周期的末尾
        state = env.get_machine_doable_action()  # 获取可以执行的操作
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    # for i in range(len(o)):
                    #     job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                    #     if job_id == o[i].job_id:
                    #         for j in range(len(o[i].ops)):
                    #             if step_id == o[i].ops[j].step_id:
                    #                 processing_time[ops_id] = o[i].ops[j].processing_time  # 使用某一种排序算法，每次循环比较processing time的大小，若小移到队列前面。
                    #         break
                    his.append(ops_id)
        for i in his:
            if i not in res:
                res.append(i)    #去除重复元素

        n = len(res)
        # 遍历所有数组元素
        # for ops_id in res:
        #     if ops_id/8!=0:
        #         job_id, step_id = env.job_manager.sur_index_dict[ops_id - 1]
        #         prend_time[ops_id] = env.job_manager.jobs[job_id].ops[step_id].endtime
        for i in range(n):
            # 最后i个元素已经排好序，无需再比较
            for j in range(n - i - 1):
                # 如果当前元素比后面的元素大，则交换它们
                cc1=prend_time(env,res[j],m)
                cc2=prend_time(env,res[j + 1],m)
                if  cc1>cc2 :
                    kk=res[j]
                    res[j] = res[j + 1]
                    res[j+1]=kk
                # elif prend_time(env,res[j],m)==prend_time(env,res[j+1],m):
                #     temp.append(res[j])
                #     temp.append(res[j+1])
                #     temp = random.sample(temp, len(temp))
                #     res[j]=temp[0]
                #     res[j+1]=temp[1]

        for ops_id in res:
            for machine_id in range(m):
                for xx in state[machine_id]:
                    if ops_id == xx:
                        machine_input[machine_id].put(ops_id)  # 对于某个机器所对应的操作集，如果ops_id不在集合中就加入进去，同时加到队列里
        available_machines_id = env.get_available_machines_id()  # 获得所有空闲的机器的序号
        if not available_machines_id:
            env.process_one_second()  # 获取不到可用的机器序号，意味着机器都在工作，那么就让他们保持工作。
        else:  # 有机器可以使用

                #两个流同时（都）执行
                # for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
                #     if machine_id in available_machines_id:
                # if multilink(env, machine_input, available_machines_id):  # 存在节点中有多于两条流的后继节点不同等待的情况

                # for q in machine_input:
                #  if machine_id in available_machines_id:
                #
                #         if not q.empty():
                #             ops_id = q.get()
                #             job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                #             operation = env.job_manager[job_id][step_id]
                #             operation.machine_id = machine_id
                #             machine = env.machine_manager[machine_id]
                #             action = operation
                #             machine.transit(env.global_time, action)
                for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
                    if machine_id in available_machines_id:
                        readyflow=[]
                        machine_list=[]
                        a,b=multilink(env,machine_q)
                        if not machine_q.empty() and a:  # 如果队列里有元素
                            xx=b
                            readyflow.append(xx[0])
                            del xx[0]
                            pp=[]
                            machine_list.extend(list(machine_q.queue))
                            for i in range(len(xx)):
                                readyflow.append(machine_list[xx[i]-1])

                            for ops in readyflow:
                                job_id,step_id=env.job_manager.sur_index_dict[ops]
                                operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                                machine_id = operation.machine_id  # 矩阵里的机器序号
                                machine = env.machine_manager[machine_id]
                                action = operation
                                pp.append(action)
                            machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                        elif not machine_q.empty():
                            ops_id = machine_q.get(0)  # 从队列里读取元素赋值给ops_id
                            job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                            # sur_index_dict（）：Job中包含的按顺序编号的操作
                            # 从集合中读出job_id和step_id，例如job0 step 0 ，表示作业0的第0步工序
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            # action=operation
                            # operation.start_time = env.global_time
                            # next_free_time = env.finish_times(machine, operation, env.global_time)
                            # if next_free_time is None or operation.start_time >= next_free_time:
                            #     machine.transit(env.global_time, action)
                            action = operation
                            machine.transit(env.global_time, action)  # 进行一个动作并且返回奖励值

        reward += env.cal_reward()  # 累加奖励值
        count += 1  # 次数加一
    return reward / count


def asapmax(env,b,myiter:int,ceil):#找到当前错误节点的前驱节点状态，在这个状态中改变调度顺序。重新进行调度。
    # env.reset()
    pp=[]

    k = True          #为真表示没有遍历过所有可能性
    for i in range(50):
       c,d,e,f,g=env.stepmax(env.action_space.sample(),b,myiter,ceil)
       if myiter==g-1:
           k=False        #表示已经遍历完所有可能性
    if  k and myiter!=0:
        a,pp=kediaodu(env)
    else:
        # op=[]
        # for i in env.job_manager.jobs:
        #     if isin(i,b):
        #         for opp in env.job_manager.jobs[i]:
        #             if opp.next_op.processing_time==0:
        #                 op=opp
        #                 break
        # if getpreop(op,ceil+1) and k:
          a,b=kediaodu(env)
    return a,b,k


def asapmaxrule(env):
        """As Soon As Possible Plus."""
        m = env.num_machines  # m=机器数
        o = []
        res = []
        temp = []
        processing_time = [0] * 1000
        for i in range(len(env.job_manager.jobs)):
            o.append(env.job_manager.jobs[i])
        machine_input = [queue.Queue() for _ in range(m)]  # 创建一个队列，用于存储等待处理的作业
        his = []  # set函数创建一个无序不重复元素的集合，用于跟踪已经被分配到机器的作业
        reward, count = 0, 0
        t = env.global_time  # 仿真时间
        while env.global_time - t < env.schedule_cycle:
            #  循环直到仿真时间到达调度周期的末尾
            state = env.get_machine_doable_action()  # 获取可以执行的操作
            done = env.is_done()
            for machine_id in range(len(machine_input)):
                machine_input[machine_id].queue.clear()
            if done:
                break

            for machine_id in range(m):
                for ops_id in state[machine_id]:
                    if ops_id not in his:
                        # for i in range(len(o)):
                        #     job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        #     if job_id == o[i].job_id:
                        #         for j in range(len(o[i].ops)):
                        #             if step_id == o[i].ops[j].step_id:
                        #                 processing_time[ops_id] = o[i].ops[j].processing_time  # 使用某一种排序算法，每次循环比较processing time的大小，若小移到队列前面。
                        #         break
                        his.append(ops_id)
            for i in his:
                if i not in res:
                    res.append(i)  # 去除重复元素

            n = len(res)
            # 遍历所有数组元素
            # for ops_id in res:
            #     if ops_id/8!=0:
            #         job_id, step_id = env.job_manager.sur_index_dict[ops_id - 1]
            #         prend_time[ops_id] = env.job_manager.jobs[job_id].ops[step_id].endtime
            # for i in range(n):
            #     # 最后i个元素已经排好序，无需再比较
            #     for j in range(n - i - 1):
            #         # 如果当前元素比后面的元素大，则交换它们
            #
            #         if prend_time(env, res[j], m) > prend_time(env, res[j + 1], m):
            #             res[j], res[j + 1] = res[j + 1], res[j]
            #         # elif prend_time(env,res[j],m)==prend_time(env,res[j+1],m):
            #         #     temp.append(res[j])
            #         #     temp.append(res[j+1])
            #         #     temp = random.sample(temp, len(temp))
            #         #     res[j]=temp[0]
            #         #     res[j+1]=temp[1]
            random.shuffle(res)
            for ops_id in res:
                for machine_id in range(m):
                    for xx in state[machine_id]:
                        if ops_id == xx:
                            machine_input[machine_id].put(ops_id)  # 对于某个机器所对应的操作集，如果ops_id不在集合中就加入进去，同时加到队列里
            available_machines_id = env.get_available_machines_id()  # 获得所有空闲的机器的序号
            if not available_machines_id:
                env.process_one_second()  # 获取不到可用的机器序号，意味着机器都在工作，那么就让他们保持工作。
            else:  # 有机器可以使用
                # 两个流同时（都）执行
                # for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
                #     if machine_id in available_machines_id:
                # if multilink(env, machine_input, available_machines_id):  # 存在节点中有多于两条流的后继节点不同等待的情况

                # for q in machine_input:
                #  if machine_id in available_machines_id:
                #
                #         if not q.empty():
                #             ops_id = q.get()
                #             job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                #             operation = env.job_manager[job_id][step_id]
                #             operation.machine_id = machine_id
                #             machine = env.machine_manager[machine_id]
                #             action = operation
                #             machine.transit(env.global_time, action)
                for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
                    if machine_id in available_machines_id:
                        readyflow = []
                        machine_list = []
                        a, b = multilink(env, machine_q)
                        if not machine_q.empty() and a:  # 如果队列里有元素
                            xx = b
                            readyflow.append(xx[0])
                            del xx[0]
                            pp = []
                            machine_list.extend(list(machine_q.queue))
                            for i in range(len(xx)):
                                readyflow.append(machine_list[xx[i] - 1])

                            for ops in readyflow:
                                job_id, step_id = env.job_manager.sur_index_dict[ops]
                                operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                                machine_id = operation.machine_id  # 矩阵里的机器序号
                                machine = env.machine_manager[machine_id]
                                action = operation
                                pp.append(action)
                            machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                        elif not machine_q.empty():
                            ops_id = machine_q.get()  # 从队列里读取元素赋值给ops_id
                            job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                            # sur_index_dict（）：Job中包含的按顺序编号的操作
                            # 从集合中读出job_id和step_id，例如job0 step 0 ，表示作业0的第0步工序
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            # action=operation
                            # operation.start_time = env.global_time
                            # next_free_time = env.finish_times(machine, operation, env.global_time)
                            # if next_free_time is None or operation.start_time >= next_free_time:
                            #     machine.transit(env.global_time, action)
                            action = operation
                            machine.transit(env.global_time, action)  # 进行一个动作并且返回奖励值
            reward += env.cal_reward()  # 累加奖励值
            count += 1  # 次数加一
        return reward / count


def asapROT(env):
    m = env.num_machines  # m=机器数
    o = []
    res = []
    temp = []
    processing_time = [0] * 1000
    for i in range(len(env.job_manager.jobs)):
        o.append(env.job_manager.jobs[i])
    machine_input = [queue.Queue() for _ in range(m)]  # 创建一个队列，用于存储等待处理的作业
    his = []  # set函数创建一个无序不重复元素的集合，用于跟踪已经被分配到机器的作业
    reward, count = 0, 0
    t = env.global_time  # 仿真时间
    while env.global_time - t < env.schedule_cycle:
        #  循环直到仿真时间到达调度周期的末尾
        state = env.get_machine_doable_action()  # 获取可以执行的操作
        done = env.is_done()
        for machine_id in range(len(machine_input)):
            machine_input[machine_id].queue.clear()
        if done:
            break

        for machine_id in range(m):
            for ops_id in state[machine_id]:
                if ops_id not in his:
                    his.append(ops_id)
        for i in his:
            if i not in res:
                res.append(i)  # 去除重复元素

        n = len(res)
        #比较当前可执行操作的剩余总时延，时延越大越优先执行
        for i in range(n - 1):
            for j in range(n - i - 1):
                if get_rest_time(env,res[j]) < get_rest_time(env,res[j + 1]):
                    res[j], res[j + 1] = res[j + 1], res[j]
        # res.reverse()         # alap,与asap倒序排列
        #剩余跳数数量两个方向，最大跳数和最小跳数 mor和lor两个算法
        #跳数数量和时间的权值=按照数据量大小做排序
        # for i in range(n-1):
        #     for j in range(n-i-1):
        #         if get_weight_time_op(env,res[j])<get_weight_time_op(env,res[j+1]):
        #             res[j], res[j + 1] = res[j + 1], res[j]
        # res.reverse()
        #同时考虑剩余跳数和剩余操作时间,以剩余时间为首要优化目标，以剩余跳数为次要优化目标
        # for i in range(n-1):
        #     for j in range(n-i-1):
        #         if get_rest_time(env,res[j])<get_rest_time(env,res[j+1]):
        #             res[j], res[j + 1] = res[j + 1], res[j]
        #         elif get_rest_time(env,res[j])==get_rest_time(env,res[j+1]):
        #             if env.get_num_remain_ops(res[j])<env.get_num_remain_ops(res[j+1]):
        #                 res[j], res[j + 1] = res[j + 1], res[j]
        # res.reverse()
        #前一跳的开始时间？
        # for i in range(n):
        #     # 最后i个元素已经排好序，无需再比较
        #     for j in range(n - i - 1):
        #         # 如果当前元素比后面的元素大，则交换它们
        #         cc1=prstart_time(env,res[j],m)
        #         cc2=prstart_time(env,res[j + 1],m)
        #         if  cc1>cc2 :
        #             kk=res[j]
        #             res[j] = res[j + 1]
        #             res[j+1]=kk
        # res.reverse()
        #占用交换机数量
        # for i in range(n):
        #     for j in range(n-i-1):
        #         if get_switch_num(env,res[j],m)<get_switch_num(env,res[j+1],m):
        #             res[j], res[j + 1] = res[j + 1], res[j]
        # res.reverse()

        for ops_id in res:
            for machine_id in range(m):
                for xx in state[machine_id]:
                    if ops_id == xx:
                        machine_input[machine_id].put(ops_id)  # 对于某个机器所对应的操作集，如果ops_id不在集合中就加入进去，同时加到队列里
        available_machines_id = env.get_available_machines_id()  # 获得所有空闲的机器的序号
        if not available_machines_id:
            env.process_one_second()  # 获取不到可用的机器序号，意味着机器都在工作，那么就让他们保持工作。
        else:  # 有机器可以使用
            for machine_id, machine_q in enumerate(machine_input):  # enumerate可以同时读取索引和元素值
                if machine_id in available_machines_id:
                    readyflow = []
                    machine_list = []
                    a, b = multilink(env, machine_q)
                    if not machine_q.empty() and a:  # 如果队列里有元素
                        xx = b
                        readyflow.append(xx[0])
                        del xx[0]
                        pp = []
                        machine_list.extend(list(machine_q.queue))
                        for i in range(len(xx)):
                            readyflow.append(machine_list[xx[i] - 1])

                        for ops in readyflow:
                            job_id, step_id = env.job_manager.sur_index_dict[ops]
                            operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                            machine_id = operation.machine_id  # 矩阵里的机器序号
                            machine = env.machine_manager[machine_id]
                            action = operation
                            pp.append(action)
                        machine.transite(env.global_time, pp)  # 进行一个动作并且返回奖励值

                    elif not machine_q.empty():
                        ops_id = machine_q.get()  # 从队列里读取元素赋值给ops_id
                        job_id, step_id = env.job_manager.sur_index_dict[ops_id]
                        operation = env.job_manager[job_id][step_id]  # job_id和step_id所对应的矩阵的元素
                        machine_id = operation.machine_id  # 矩阵里的机器序号
                        machine = env.machine_manager[machine_id]
                        action = operation
                        machine.transit(env.global_time, action)  # 进行一个动作并且返回奖励值
        reward += env.cal_reward()  # 累加奖励值
        count += 1  # 次数加一
    return reward / count

def kediaodu(env):
    flowinitial_end_time=[58,58,58,58,58,58,58]
    flowcandidate_end_time=[]
    # for _ in range(50):
    #     env.step(env.action_space.sample())  # take a random action#做一个标志表示初始解。并在这个过程中使用asap作为调度算法
    for i in range(len(env.job_manager.jobs)):
        for j in range(len(env.job_manager.jobs[i].ops)):
            if env.job_manager.jobs[i].ops[j].next_op.processing_time==0:
                flowcandidate_end_time.append(env.job_manager.jobs[i].ops[j].end_time)
                break
            else:
                continue
    #获得每条流的最大延迟，当一条流在规定的调度延迟内没有完成调度，则判定为调度失败，返回上一条节点重新调度。
    #初始结果是以asap的调度结果作为初始解。后续调度是以随机解作为调度起始。需要记录每一次调度失败的流，
    # env.reset()
    # for _ in range(50):
    #     env.stepmaxrule(env.action_space.sample())  # 采取另一个asapmax算法，核心是随机进行调度得到的结果跟初始解作对比
    # for i in range(len(env.job_manager.jobs)):
    #     for j in range(len(env.job_manager.jobs[i].ops)):
    #         if env.job_manager.jobs[i].ops[j].next_op.processing_time==0:
    #             flowinitial_end_time.append(env.job_manager.jobs[i].ops[j].end_time)
    #             break
    #         else:
    #             continue
    wrongflow=[]
    for i in range(len(flowinitial_end_time)):
        if flowcandidate_end_time[i]>flowinitial_end_time[i]:
            wrongflow.append(i)
        else:
            continue
    if not wrongflow:
        return True, None
    else:
        return False, wrongflow


def prend_time(env,ops_id,m):
    cc=0
    if ops_id%m!=0:
        job_id, step_id = env.job_manager.sur_index_dict[ops_id - 1]
        cc=env.job_manager.jobs[job_id].ops[step_id].end_time
    return cc

def prstart_time(env,ops_id,m):
    cc = 0
    if ops_id % m != 0:
        job_id, step_id = env.job_manager.sur_index_dict[ops_id - 1]
        cc = env.job_manager.jobs[job_id].ops[step_id].start_time
        return cc
    else:
        return cc

def nextnode(env,ops_id):
    m_matrix=env.machine_matrix
    job_id, step_id = env.job_manager.sur_index_dict[ops_id]
    p_matrix=env.processing_time_matrix
    if p_matrix[job_id][step_id]==0:
        nextnode=None
    else:
        nextnode=m_matrix[job_id][step_id+1]
    return nextnode

def multilink(env,machine_q):
    ivy=[]
    n=machine_q.qsize()
    if machine_q.qsize()==1:
        return [False,None]
    else:
        x=0
        pareflow = []
        xx = []
        ops_id = machine_q.get()
        xx.append(ops_id)
        readyflow = nextnode(env,ops_id)
        if readyflow is None:
            for i in range(n-1):
                ivy.append(machine_q.get())
            machine_q.put(ops_id)
            for v in range(n-1):
                machine_q.put(ivy[v])
            # machine_q=list(machine_q.queue)
            # machine_q=deque(machine_q)
            # machine_q.appendleft(ops_id)
            return [False,None]
        for item in range(machine_q.qsize()):
            pareflow.append(nextnode(env,machine_q.queue[item]))
        for i in range(len(pareflow)):
            if readyflow!=pareflow[i]:
                xx.append(i+1)
                x=1
            else:
                continue
        if x==0:
            for i in range(n - 1):
                ivy.append(machine_q.get())
            machine_q.put(ops_id)
            for v in range(n - 1):
                machine_q.put(ivy[v])
            return [False, None]
        else:
            return [True, xx]



                # for i in range(len(machine_q)):
                #
                 # ops_id=[]
                 # ops_id.append(machine_q.get()) # 从队列里读取元素赋值给ops_id
                 # m_matrix=env.machine_matrix
                 # p_matrix=env.processing_time_matrix
                 # nextnode=[]
                 # for i in len(ops_id):
                 #     job_id, step_id = env.job_manager.sur_index_dict[ops_id[i]]
                 #     nextnode[i]=m_matrix[job_id][step_id+1]

                # for i in range(len(nextnode)):
                #     for j in range(i+1,len(nextnode)):
                #         if nextnode[i]==nextnode[j]:
                #             return False
                #         else:
                #             #找回上一个节点
                #
                #             return True,ops_id

def multilinke(env,machine_q):
    if machine_q.qsize()==1:
        return [False,None]
    else:
        pareflow = []
        xx = []
        cc=0
        ops_id = machine_q.get()
        ops_id=ops_id[1]
        xx.append(ops_id)
        readyflow = nextnode(env,ops_id)
        if readyflow is None:
            return [False,None]
        for item in range(machine_q.qsize()):
            pareflow.append(nextnode(env,machine_q.queue[item][1]))
        for i in range(len(pareflow)):
            if readyflow!=pareflow[i]:
                xx.append(i+1)
                cc=1
            else:
                return [False,None]
        if cc==1:
            return [True, xx]

def getnextop(op,ceil):

    for i in range(ceil):
        if op.next_op is None:
            return None
        op = op.next_op
        return op

def getpreop(op,ceil):
    if not op:
        return True

    for i in range(ceil):
        op=op.prev_op
    if op is None:
        return True
    else:
         return False
def isin(lo,b):
    if b==None:
        return False
    elif lo in b:
        return True
    else:
        return False

def get_rest_time(env,res):
    rest_time=0
    job_id, step_id = env.job_manager.sur_index_dict[res]
    operation = env.job_manager[job_id][step_id]
    while operation.processing_time!=0:
        rest_time=rest_time+operation.processing_time
        operation=operation.next_op
    return rest_time

def get_switch_num(env,ops_id,m):
    flow=ops_id/m
    num=0
    job_id, step_id = env.job_manager.sur_index_dict[ops_id]
    operation = env.job_manager[job_id][step_id]
    if operation.processing_time!=0 and operation.prev_op is not None:
        operation=operation.next_op
        num=num+1
    return num

def get_weight_time_op(env,ops_id):
    weight=0
    if get_rest_time(env, ops_id)!=0:
        weight=env.get_num_remain_ops(ops_id) / get_rest_time(env, ops_id)
    else:
        weight=0
    return weight




