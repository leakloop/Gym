
#用来生成流量、初始化网络资源、设置网络拓扑、寻找所有路径

import random as rd
import numpy as np


def flow_generate(flow_number):          #用来生成流量
    f = np.array([rd.randrange(64,1512,1) for i in range(flow_number)])
    t = np.array([rd.randrange(1,4,1) for i in range(flow_number)])
    src = np.array(rd.sample(range(9),k=9))
    dst = np.array(rd.sample(range(9),k=9))
    # src = np.array([rd.randrange(0, 8, 1) for i in range(flow_number)])
    # dst = np.array([rd.randrange(0, 8, 1) for i in range(flow_number)])

    t.reshape([-1,flow_number])
    src.reshape([-1,flow_number])
    dst.reshape([-1,flow_number])
    for i in range(flow_number):
        if src[i] == dst[i]:
            temp = rd.randrange(0, 7, 1)
            hosts = []
            for j in range(8):
                if j+1 != src[i]:
                    hosts.append(j+1)
            dst[i] = hosts[temp]
        if t[i] == 3:
            t[i] = 4

    flow = np.array([[0 for i in range(4)]for j in range(flow_number)])
    flow[:,0]=src
    flow[:,1]=dst
    flow[:,2]=t
    flow[:,3]=f
    return flow
flow_number = 9

flow = flow_generate(flow_number)

network = [[0,0,0,0,0,0,0,0,1,0,0],             #网络拓扑邻接矩阵
           [0,0,0,0,0,0,0,0,1,0,0],
           [0,0,0,0,0,0,0,0,1,0,0],
           [0,0,0,0,0,0,0,0,0,1,0],
           [0,0,0,0,0,0,0,0,0,1,0],
           [0,0,0,0,0,0,0,0,0,1,0],
           [0,0,0,0,0,0,0,0,0,0,1],
           [0,0,0,0,0,0,0,0,0,0,1],
           [1,1,1,0,0,0,0,0,0,1,1],
           [0,0,0,1,1,1,0,0,1,0,1],
           [0,0,0,0,0,0,1,1,1,1,0]]

network2 = [[0,0,0,0,0,0,0,0,1,0,0,0],
            [0,0,0,0,0,0,0,0,1,0,0,0],
            [0,0,0,0,0,0,0,0,0,1,0,0],
            [0,0,0,0,0,0,0,0,0,1,0,0],
            [0,0,0,0,0,0,0,0,0,0,1,0],
            [0,0,0,0,0,0,0,0,0,0,1,0],
            [0,0,0,0,0,0,0,0,0,0,0,1],
            [0,0,0,0,0,0,0,0,0,0,0,1],
            [1,1,0,0,0,0,0,0,0,1,1,1],
            [0,0,1,1,0,0,0,0,1,0,1,1],
            [0,0,0,0,1,1,0,0,1,1,0,1],
            [0,0,0,0,0,0,1,1,1,1,1,0]]

def iter_paths(adj, min_length=2, path=None): #深度优先算法寻找所有路径
    if not path:
        for start_node in range(len(adj)):
            yield from iter_paths(adj, min_length, [start_node])
    else:
        # yield a path as soon as we first encounter it
        if len(path) >= min_length:
            yield path
        # if we encounter a cycle (current location has been visited before)
        # then don't continue to recur
        if path[-1] in path[:-1]:
            return
        # search for all paths forward from the current node, recursively
        current_node = path[-1]
        for next_node in range(len(adj[current_node])):
            if adj[current_node][next_node] == 1:
                yield from iter_paths(adj, min_length, path + [next_node])
paths = list(iter_paths(network))

paths2 = list(iter_paths(network2))

def find_path(src,dst,paths):                        #寻找源节点和目的节点为特定值的路径
    path = []
    for i in paths:
        a = i[0]
        b = i[-1]
        if a == src :
            if b == dst:
                path.append(i)
    return path

path = []
pathlen = []
path_short = [[] for i in range(flow_number)]
short_path = []
for i in range(len(flow)):
    p = find_path(flow[i][0], flow[i][1], paths)
    pathlen.append(len(p))
    path.append(p)
    if len(p) == 1:
        path_short[i].append(p[0])

    if len(p) >= 2:
        for j in range(1,len(p)):
            temp = len(path[i][0])
            if len(path[i][j]) < temp:
                path_short[i].append(path[i][j])
            else:

                path_short[i].append(path[i][0])

for i in range(flow_number):
    short_path.append(path_short[i][0])

time_list = [[] for i in range(flow_number)]
for i in range(flow_number):
    for j in range(len(short_path[i])):
        if j ==0:
            time_list[i].append(flow[i][2])
        elif j ==len(short_path[i])-1:
            time_list[i].append(0)
        else:
            time_list[i].append(flow[i][2]+2)

times = np.array([np.pad(row, (0, 11-len(row)), 'constant') for row in time_list])
machines = np.array([np.pad(row, (0, 11-len(row)), 'constant') for row in short_path])


max_num = machines[0][0]
for row in machines:
    for item in row:
        if item > max_num:
            max_num = item
print('生成的最短路径为',machines)
print('生成的调度时间为',times)
# print(len(times))
# print(max_num+1)