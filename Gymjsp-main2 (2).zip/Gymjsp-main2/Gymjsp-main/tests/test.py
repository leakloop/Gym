import os
os.sys.path.insert(0, '../gymjsp')
#0表示插入的索引位置，后面表示插入的内容
from gymjsp.jsspenv import HeuristicAttentionJsspEnv
from gymjsp.heuristicRule import (kediaodu,asapmax)
env = HeuristicAttentionJsspEnv('la04', schedule_cycle=2)

# #
for _ in range(200):
    env.step(env.action_space.sample())  # take a random action
# a=False
# b = []
# myiter=0
# ceil=1
# while not a:
#     env.reset()
#     a,b,k=asapmax(env,b,myiter,ceil)  # 返回上一个节点进行调度
#     myiter = myiter + 1
#     if not k:
#         myiter=0
#         ceil=ceil+1
#     # 需要一个参数表示在当前节点已经全部迭代晚，需要再返回上一层进行迭代,iter迭代完后发现iter的值等于res中参数个数的二次方


#在其他流已经调度完成的情况下，完成对单条流的调度
#流在每个交换机节点的可行域通过其他流的调度来完成，当流到达交换机节点时的时间为可行域的上界

env.render()

